﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    class Mensalista : Empregado
    {
        public double SalarioMensal { get; set; }

        public double SalarioHora { get; set; }
        public double NumeroHora { get; set; }
        public int DiasFaltas { get; set; }
        public Mensalista()
        {

        }
        //isso é uma sobrecarga
        public Mensalista(int matx, string nomex , DateTime datax , double salariox)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal = salariox;


        }


        //Sobreescrever o metódo
        public override double SalarioBruto()
        {
            return (SalarioHora * NumeroHora);
        }
        public override int TempoTrabalho()
        {
            //metodo retorna um tipo span
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (Convert.ToInt32(span.Days) - DiasFaltas);
        }
    }
}
