﻿
namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblMatricula = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblSalarioHora = new System.Windows.Forms.Label();
            this.LblNumeroHora = new System.Windows.Forms.Label();
            this.LblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.LblDiasFalta = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.txtNumeroHora = new System.Windows.Forms.TextBox();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.txtDiasFalta = new System.Windows.Forms.TextBox();
            this.BtnInstanciarHorista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblMatricula
            // 
            this.LblMatricula.AutoSize = true;
            this.LblMatricula.BackColor = System.Drawing.SystemColors.Menu;
            this.LblMatricula.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMatricula.Location = new System.Drawing.Point(93, 80);
            this.LblMatricula.Name = "LblMatricula";
            this.LblMatricula.Size = new System.Drawing.Size(61, 20);
            this.LblMatricula.TabIndex = 0;
            this.LblMatricula.Text = "Mátricula";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.BackColor = System.Drawing.SystemColors.Menu;
            this.LblNome.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNome.Location = new System.Drawing.Point(93, 114);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(43, 20);
            this.LblNome.TabIndex = 1;
            this.LblNome.Text = "Nome";
            // 
            // LblSalarioHora
            // 
            this.LblSalarioHora.AutoSize = true;
            this.LblSalarioHora.BackColor = System.Drawing.SystemColors.Menu;
            this.LblSalarioHora.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSalarioHora.Location = new System.Drawing.Point(93, 148);
            this.LblSalarioHora.Name = "LblSalarioHora";
            this.LblSalarioHora.Size = new System.Drawing.Size(100, 20);
            this.LblSalarioHora.TabIndex = 2;
            this.LblSalarioHora.Text = "Salario Por Hora";
            // 
            // LblNumeroHora
            // 
            this.LblNumeroHora.AutoSize = true;
            this.LblNumeroHora.BackColor = System.Drawing.SystemColors.Menu;
            this.LblNumeroHora.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNumeroHora.Location = new System.Drawing.Point(93, 182);
            this.LblNumeroHora.Name = "LblNumeroHora";
            this.LblNumeroHora.Size = new System.Drawing.Size(109, 20);
            this.LblNumeroHora.TabIndex = 3;
            this.LblNumeroHora.Text = "Numero De Horas";
            // 
            // LblDataEntradaEmpresa
            // 
            this.LblDataEntradaEmpresa.AutoSize = true;
            this.LblDataEntradaEmpresa.BackColor = System.Drawing.SystemColors.Menu;
            this.LblDataEntradaEmpresa.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDataEntradaEmpresa.Location = new System.Drawing.Point(93, 216);
            this.LblDataEntradaEmpresa.Name = "LblDataEntradaEmpresa";
            this.LblDataEntradaEmpresa.Size = new System.Drawing.Size(172, 20);
            this.LblDataEntradaEmpresa.TabIndex = 4;
            this.LblDataEntradaEmpresa.Text = "Data De Entrada Na Empresa";
            // 
            // LblDiasFalta
            // 
            this.LblDiasFalta.AutoSize = true;
            this.LblDiasFalta.BackColor = System.Drawing.SystemColors.Menu;
            this.LblDiasFalta.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDiasFalta.Location = new System.Drawing.Point(93, 250);
            this.LblDiasFalta.Name = "LblDiasFalta";
            this.LblDiasFalta.Size = new System.Drawing.Size(84, 20);
            this.LblDiasFalta.TabIndex = 5;
            this.LblDiasFalta.Text = "Dias De Falta";
            // 
            // txtMatricula
            // 
            this.txtMatricula.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtMatricula.Location = new System.Drawing.Point(301, 77);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 6;
            // 
            // txtNome
            // 
            this.txtNome.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtNome.Location = new System.Drawing.Point(301, 111);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 7;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtSalarioHora.Location = new System.Drawing.Point(301, 145);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioHora.TabIndex = 8;
            // 
            // txtNumeroHora
            // 
            this.txtNumeroHora.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtNumeroHora.Location = new System.Drawing.Point(301, 179);
            this.txtNumeroHora.Name = "txtNumeroHora";
            this.txtNumeroHora.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroHora.TabIndex = 9;
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(301, 213);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(100, 20);
            this.txtDataEntradaEmpresa.TabIndex = 10;
            // 
            // txtDiasFalta
            // 
            this.txtDiasFalta.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtDiasFalta.Location = new System.Drawing.Point(301, 247);
            this.txtDiasFalta.Name = "txtDiasFalta";
            this.txtDiasFalta.Size = new System.Drawing.Size(100, 20);
            this.txtDiasFalta.TabIndex = 11;
            // 
            // BtnInstanciarHorista
            // 
            this.BtnInstanciarHorista.BackColor = System.Drawing.SystemColors.GrayText;
            this.BtnInstanciarHorista.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnInstanciarHorista.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInstanciarHorista.ForeColor = System.Drawing.SystemColors.ControlText;
            this.BtnInstanciarHorista.Location = new System.Drawing.Point(131, 318);
            this.BtnInstanciarHorista.Name = "BtnInstanciarHorista";
            this.BtnInstanciarHorista.Size = new System.Drawing.Size(236, 47);
            this.BtnInstanciarHorista.TabIndex = 12;
            this.BtnInstanciarHorista.Text = "Instanciar Horista";
            this.BtnInstanciarHorista.UseVisualStyleBackColor = false;
            this.BtnInstanciarHorista.Click += new System.EventHandler(this.BtnInstanciarHorista_Click);
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnInstanciarHorista);
            this.Controls.Add(this.txtDiasFalta);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtNumeroHora);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.LblDiasFalta);
            this.Controls.Add(this.LblDataEntradaEmpresa);
            this.Controls.Add(this.LblNumeroHora);
            this.Controls.Add(this.LblSalarioHora);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.LblMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblMatricula;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblSalarioHora;
        private System.Windows.Forms.Label LblNumeroHora;
        private System.Windows.Forms.Label LblDataEntradaEmpresa;
        private System.Windows.Forms.Label LblDiasFalta;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.TextBox txtNumeroHora;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtDiasFalta;
        private System.Windows.Forms.Button BtnInstanciarHorista;
    }
}