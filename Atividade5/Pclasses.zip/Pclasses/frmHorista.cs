﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void BtnInstanciarHorista_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            //set - atribui os valores do objeto
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.SalarioHora = Convert.ToInt32(txtSalarioHora.Text);
            objHorista.NumeroHora = Convert.ToInt32(txtNumeroHora.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);
            objHorista.DiasFaltas = Convert.ToInt32(txtDiasFalta.Text);
            //get - imprime os valores do objeto
            MessageBox.Show("Nome: " + objHorista.NomeEmpregado + "\n" +
                            "Mátricula: " + objHorista.Matricula + "\n" +
                            "Tempo de Trabalho: " + objHorista.TempoTrabalho().ToString() + "\n" +
                            "Salario Mensal : " + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
