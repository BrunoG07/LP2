﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P30482023041
{
    public partial class Form1 : Form
    {    

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int N = 1; //último digito do meu RA.
            double[,] Vendas = new double[N, 4];
            double TotalVenda = 0, TotalGeral = 0;
            string Dado = "";

            for (var i = 0; i < N; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    Dado = Interaction.InputBox("Digite o saldo da " + (j + 1).ToString() + " semana do mês: " + (i + 1).ToString(), "Entrada de Notas");
                    if (!double.TryParse(Dado, out Vendas[i, j]))
                    {
                        MessageBox.Show("Valor incorreto!");
                        j--;
                        Dado = "";
                    }
                }
            }
            for (var i = 0; i < N; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    ListBoxValores.Items.Add("\n Total do mês " + (i + 1).ToString() + " da semana: " + (j + 1).ToString() + " " + Vendas[i, j].ToString("C"));
                    TotalVenda += Vendas[i, j];
                }
                ListBoxValores.Items.Add("\n Total do Mês: " + TotalVenda.ToString("C"));
                ListBoxValores.Items.Add("......................................................");
                TotalGeral += TotalVenda;
            }
            ListBoxValores.Items.Add("\n Total geral: " + TotalGeral.ToString());
        }
    }
}
