﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PATIVIDADE8
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExercicio6_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            string Dado = "";
            double[] Media = new double[20];
            string Mediatexto = "";

            for(var i = 0; i < 20; i++)
            {
                for(var j = 0; j < 3; j++)
                {
                    Dado = Interaction.InputBox("Digite a " + (j + 1).ToString() + " nota do Aluno: " + (i + 1).ToString(), "Entrada de Notas");
                    Notas[i, j] = Convert.ToDouble(Dado);
                    Dado = "";
                }
            }
            for(var k = 0; k < 20; k++)
            {
                Media[k] = (Notas[k, 0] + Notas[k, 1] + Notas[k, 2]) / 3;
                Mediatexto += "\n" + "Aluno " + (k + 1).ToString() + " nota: " + Media[k].ToString();
            }
            MessageBox.Show("Médias: " + Mediatexto);


            
        }
    }
}
