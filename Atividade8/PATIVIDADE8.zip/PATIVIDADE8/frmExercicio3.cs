﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PATIVIDADE8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            int[] Vetor = new int[10];
            string Dado = "";
            int[] Qtde = new int[10];
            double[] Preco = new double[10];
            double Valor = 0;
            for(var i = 0; i < Vetor.Length; i++)
            {
                Dado = Interaction.InputBox("Digite a quantidade vendida do " + (i + 1).ToString() + " item ", "Entrada de Dados");
                if(!int.TryParse(Dado, out Qtde[i]))
                {
                    MessageBox.Show("Dado inválido!");
                    i--;
                }
                Dado = "";
            }
            for(var i = 0; i < Vetor.Length; i++)
            {
                Dado = Interaction.InputBox("Digite o preço do" + (i + 1).ToString() + " item ", "Entrada de Dados");
                if (!double.TryParse(Dado, out Preco[i]))
                {
                    MessageBox.Show("Dado inválido!");
                    i--;
                }
                Dado = "";
            }
            for(var i = 0; i < Vetor.Length; i++)
            {
                Valor += Qtde[i] * Preco[i];
            }
            MessageBox.Show("Valor Mensal das Mercadorias: " + Valor);
        }
    }
}
