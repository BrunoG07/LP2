﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PATIVIDADE8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string lista = "";
            
            for (var i = 0; i < vetor.Length; i++)
            {
                lista = Interaction.InputBox("Digite o " + (i + 1).ToString() + " número: ", "Entrada de Dados");
                if (!int.TryParse(lista, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            lista = "";
            Array.Reverse(vetor);
            for (var i = 0; i < vetor.Length; i++)
            {
                lista += "\n" + vetor[i];
            }
            
            MessageBox.Show("Lista de números invertida: " + lista);

        }
    }
}
