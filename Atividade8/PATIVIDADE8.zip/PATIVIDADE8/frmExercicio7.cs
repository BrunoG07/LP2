﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PATIVIDADE8
{
    public partial class frmExercicio7 : Form
    {
        public frmExercicio7()
        {
            InitializeComponent();
        }

        private void btnExercicio7_Click(object sender, EventArgs e)
        {
            string Dado = "", Nomes = "";
            string[] Nome = new string[1];
            for(var i = 0; i < 1; i++)
            {
                Dado = Interaction.InputBox("Digite o nome completo da " + (i + 1).ToString() + " pessoa: ", "Entrada de Nomes");
                Nome[i] = Dado;
                Dado = "";
            }
            for(var i = 0; i < 1; i++)
            {
                Dado = Nome[i].Trim().Replace(" ", "");
                listBoxNomes.Items.Add("\n o nome: " + Nome[i] + " tem " + Dado.Length + " caracteres. ");
                Dado = "";
            }
        }
    }
}
