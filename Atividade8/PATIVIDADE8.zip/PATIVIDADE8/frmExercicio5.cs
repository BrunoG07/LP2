﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PATIVIDADE8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            List<string> Alunos = new List<string>();
            Alunos.Add("Ana");
            Alunos.Add("André");
            Alunos.Add("Débora");
            Alunos.Add("Fátima");
            Alunos.Add("João");
            Alunos.Add("Janete");
            Alunos.Add("Otávio");
            Alunos.Add("Marcelo");
            Alunos.Add("Pedro");
            Alunos.Add("Thais");

            Alunos.RemoveAt(6);
            for(var i = 0; i < 9; i++)
            {
                MessageBox.Show("Lista de alunos sem o Otávio: " + Alunos[i]);
            }
            
        }
    }
}
