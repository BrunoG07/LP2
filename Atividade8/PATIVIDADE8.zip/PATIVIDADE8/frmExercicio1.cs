﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PATIVIDADE8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string listaInv = "";
            for (var i = 0; i < vetor.Length; i++)
            {
                listaInv = Interaction.InputBox("Digite o " + (i + 1).ToString() + " número: ", "Entrada de Dados");
                if (!int.TryParse(listaInv, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            listaInv = "";
            for(var i = vetor.Length - 1; i >= 0; i--)
            {
                listaInv += "\n" + vetor[i];
            }
            MessageBox.Show("Lista de números invertida: " + listaInv);
            
        }
    }
}
