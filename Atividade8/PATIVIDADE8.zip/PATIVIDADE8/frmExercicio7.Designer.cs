﻿
namespace PATIVIDADE8
{
    partial class frmExercicio7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExercicio7 = new System.Windows.Forms.Button();
            this.listBoxNomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnExercicio7
            // 
            this.btnExercicio7.Location = new System.Drawing.Point(44, 48);
            this.btnExercicio7.Name = "btnExercicio7";
            this.btnExercicio7.Size = new System.Drawing.Size(274, 141);
            this.btnExercicio7.TabIndex = 0;
            this.btnExercicio7.Text = "Exercicio 7";
            this.btnExercicio7.UseVisualStyleBackColor = true;
            this.btnExercicio7.Click += new System.EventHandler(this.btnExercicio7_Click);
            // 
            // listBoxNomes
            // 
            this.listBoxNomes.FormattingEnabled = true;
            this.listBoxNomes.Location = new System.Drawing.Point(459, 63);
            this.listBoxNomes.Name = "listBoxNomes";
            this.listBoxNomes.Size = new System.Drawing.Size(278, 290);
            this.listBoxNomes.TabIndex = 1;
            // 
            // frmExercicio7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBoxNomes);
            this.Controls.Add(this.btnExercicio7);
            this.Name = "frmExercicio7";
            this.Text = "frmExercicio7";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExercicio7;
        private System.Windows.Forms.ListBox listBoxNomes;
    }
}