﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form
    {
        double Altura, PesoAtual, PesoIdeal;
      
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            textBox1.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (double.TryParse(maskedTextBox1.Text, out Altura) && double.TryParse(maskedTextBox2.Text, out PesoAtual))
            {
                if (Altura != 0 && PesoAtual != 0)
                {
                    PesoAtual = Math.Round(PesoAtual, 1);
                    if (double.TryParse(maskedTextBox1.Text, out Altura) && radioButton1.Checked)
                    {
                        PesoIdeal = (72.7 * Altura) - 58;
                        PesoIdeal = Math.Round(PesoIdeal, 1);
                        textBox1.Text = PesoIdeal.ToString();

                        if (PesoAtual > PesoIdeal)
                        {
                            MessageBox.Show("Você está acima do peso, por favor faça exercícios");
                        }
                        else if (PesoAtual < PesoIdeal)
                        {
                            MessageBox.Show("Você está abaixo do peso ideal, por favor se alimente!");
                        }
                        else
                        {
                            MessageBox.Show("Você está no peso ideal");
                        }
                    }
                    else if (double.TryParse(maskedTextBox1.Text, out Altura) && radioButton2.Checked)
                    {
                        PesoIdeal = (62.1 * Altura) - 44.7;
                        PesoIdeal = Math.Round(PesoIdeal, 1);
                        textBox1.Text = PesoIdeal.ToString();

                        if (PesoAtual > PesoIdeal)
                        {
                            MessageBox.Show("Você está acima do peso, por favor faça exercícios");
                        }
                        else if (PesoAtual < PesoIdeal)
                        {
                            MessageBox.Show("Você está abaixo do peso ideal, por favor se alimente!");
                        }
                        else
                        {
                            MessageBox.Show("Você está no peso ideal");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Valores ou marcações incorretas, verifique!");
                    }
                }
                else
                {
                    MessageBox.Show("Não pode usar o valor 0, digite outro número!");
                }
            }
            else
            {
                MessageBox.Show("Valores incorretos, verifique!");
            }
        }
    }
}
