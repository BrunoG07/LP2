﻿
namespace PVacina30482023041
{
    partial class frmSobre
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.logoPictureBox = new System.Windows.Forms.PictureBox();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblRA = new System.Windows.Forms.Label();
            this.LblMensagem = new System.Windows.Forms.Label();
            this.LblMateria = new System.Windows.Forms.Label();
            this.txtDescrição = new System.Windows.Forms.TextBox();
            this.okButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.ColumnCount = 2;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67F));
            this.tableLayoutPanel.Controls.Add(this.logoPictureBox, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.LblNome, 1, 0);
            this.tableLayoutPanel.Controls.Add(this.LblRA, 1, 1);
            this.tableLayoutPanel.Controls.Add(this.LblMensagem, 1, 2);
            this.tableLayoutPanel.Controls.Add(this.LblMateria, 1, 3);
            this.tableLayoutPanel.Controls.Add(this.txtDescrição, 1, 4);
            this.tableLayoutPanel.Controls.Add(this.okButton, 1, 5);
            this.tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel.Location = new System.Drawing.Point(9, 9);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 6;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(417, 265);
            this.tableLayoutPanel.TabIndex = 0;
            // 
            // logoPictureBox
            // 
            this.logoPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("logoPictureBox.Image")));
            this.logoPictureBox.Location = new System.Drawing.Point(3, 3);
            this.logoPictureBox.Name = "logoPictureBox";
            this.tableLayoutPanel.SetRowSpan(this.logoPictureBox, 6);
            this.logoPictureBox.Size = new System.Drawing.Size(131, 259);
            this.logoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoPictureBox.TabIndex = 12;
            this.logoPictureBox.TabStop = false;
            // 
            // LblNome
            // 
            this.LblNome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LblNome.Location = new System.Drawing.Point(143, 0);
            this.LblNome.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
            this.LblNome.MaximumSize = new System.Drawing.Size(0, 17);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(271, 17);
            this.LblNome.TabIndex = 19;
            this.LblNome.Text = "Nome Propriedade";
            this.LblNome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LblNome.Click += new System.EventHandler(this.LblNome_Click);
            // 
            // LblRA
            // 
            this.LblRA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LblRA.Location = new System.Drawing.Point(143, 26);
            this.LblRA.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
            this.LblRA.MaximumSize = new System.Drawing.Size(0, 17);
            this.LblRA.Name = "LblRA";
            this.LblRA.Size = new System.Drawing.Size(271, 17);
            this.LblRA.TabIndex = 0;
            this.LblRA.Text = "Versão";
            this.LblRA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblMensagem
            // 
            this.LblMensagem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LblMensagem.Location = new System.Drawing.Point(143, 52);
            this.LblMensagem.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
            this.LblMensagem.MaximumSize = new System.Drawing.Size(0, 17);
            this.LblMensagem.Name = "LblMensagem";
            this.LblMensagem.Size = new System.Drawing.Size(271, 17);
            this.LblMensagem.TabIndex = 21;
            this.LblMensagem.Text = "Copyright";
            this.LblMensagem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblMateria
            // 
            this.LblMateria.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LblMateria.Location = new System.Drawing.Point(143, 78);
            this.LblMateria.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
            this.LblMateria.MaximumSize = new System.Drawing.Size(0, 17);
            this.LblMateria.Name = "LblMateria";
            this.LblMateria.Size = new System.Drawing.Size(271, 17);
            this.LblMateria.TabIndex = 22;
            this.LblMateria.Text = "Lógica de Programação 2";
            this.LblMateria.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDescrição
            // 
            this.txtDescrição.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDescrição.Location = new System.Drawing.Point(143, 107);
            this.txtDescrição.Margin = new System.Windows.Forms.Padding(6, 3, 3, 3);
            this.txtDescrição.Multiline = true;
            this.txtDescrição.Name = "txtDescrição";
            this.txtDescrição.ReadOnly = true;
            this.txtDescrição.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDescrição.Size = new System.Drawing.Size(271, 126);
            this.txtDescrição.TabIndex = 23;
            this.txtDescrição.TabStop = false;
            this.txtDescrição.Text = "Descrição";
            // 
            // okButton
            // 
            this.okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.okButton.Location = new System.Drawing.Point(339, 239);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 24;
            this.okButton.Text = "&OK";
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // frmSobre
            // 
            this.AcceptButton = this.okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 283);
            this.Controls.Add(this.tableLayoutPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSobre";
            this.Padding = new System.Windows.Forms.Padding(9);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmSobre";
            this.Load += new System.EventHandler(this.frmSobre_Load);
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.PictureBox logoPictureBox;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblRA;
        private System.Windows.Forms.Label LblMensagem;
        private System.Windows.Forms.Label LblMateria;
        private System.Windows.Forms.TextBox txtDescrição;
        private System.Windows.Forms.Button okButton;
    }
}
