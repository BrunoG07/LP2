﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVacina30482023041
{
    partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
            this.Text = String.Format("Sobre {0}", AssemblyTitle);
            this.LblNome.Text = AssemblyProduct;
            this.LblRA.Text = String.Format("Versão {0}", AssemblyVersion);
            this.LblMensagem.Text = AssemblyCopyright;
            this.LblMateria.Text = AssemblyCompany;
            this.txtDescrição.Text = AssemblyDescription;
        }

        #region Acessório de Atributos do Assembly

        public string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public string AssemblyDescription
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public string AssemblyProduct
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        public string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }

        public string AssemblyCompany
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCompanyAttribute)attributes[0]).Company;
            }
        }
        #endregion

        private void LblNome_Click(object sender, EventArgs e)
        {
            
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmSobre_Load(object sender, EventArgs e)
        {
            LblNome.Text = "Projeto: PVacina30482023041 ";
            LblNome.Visible = true;
            LblRA.Text = "Prof Denilce Veloso";
            LblRA.Visible = true;
            LblMateria.Text = "Lógica de Programação 2 ";
            LblMateria.Visible = true;
            txtDescrição.Text = "Primeiro projeto de cadastros feito com o auxilio da professora Denilce de LP2. \r\n" +
                                "Alunos: \r\n" +
                                "Andressa Vieira Couto,\r\n" +
                                "Bruno Felipe Do Amaral Gurgel,\r\n" +
                                "Julio Cesar de Castro.\r\n";
            txtDescrição.Visible = true;
            LblMensagem.Text = "";
            LblMensagem.Visible = true;
        }
    }
}
