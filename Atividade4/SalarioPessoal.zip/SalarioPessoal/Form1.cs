﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalarioPessoal
{
    public partial class Form1 : Form
    {
        double DescontoINSS, DescontoIRPF, SalarioFamilia, SalarioBruto, SalarioLiquido, NumFilhos;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidarDesconto_Click(object sender, EventArgs e)
        {
            /*Aliquota INSS para Salário Bruto: 
            Até 800.47 - 7.65 % 
            De 800.48 a 1050 - 8.65 % 
            De 1050.01 a 1400.77 – 9.00 % 
            De 1400.78 a 2801.56 – 11.00 %
            > 2801.56 ->Desconto = 308.17(teto)

            Alíquota IRPF para Salário Bruto:
            Até 1257.12 - isento
            De 1257.13 a 2512.08 – 15.00%
            > 2512.08 - 27.5%

            Salário Família para Salário Bruto:
            Até 435.52 - 22.33 por filho
            De 435.53 a 654.61 - 15.74 por filho
            >654.61 – 0*/

            if((txtFuncionario.Text=="") || (txtFuncionario.Text.Length < 10))
            {
                MessageBox.Show("Nome Inválido!");
            }
            else if(double.TryParse(txtSalarioBruto.Text, out SalarioBruto))
            {
                // ALIQUOTA INSS
                if(SalarioBruto <= 800.47)
                {
                    txtAliquotaINSS.Text = "7.65%";
                    DescontoINSS = 0.0765 * SalarioBruto;
                }
                else if (SalarioBruto >= 800.48 && SalarioBruto <= 1050)
                {
                    txtAliquotaINSS.Text = "8.65%";
                    DescontoINSS = 0.0865 * SalarioBruto;
                }
                else if (SalarioBruto >= 1050.01 && SalarioBruto <= 1400.77)
                {
                    txtAliquotaINSS.Text = "9.00%";
                    DescontoINSS = 0.09 * SalarioBruto;
                }
                else if (SalarioBruto >= 1400.78 && SalarioBruto <= 2801.56)
                {
                    txtAliquotaINSS.Text = "11.00%";
                    DescontoINSS = 0.11 * SalarioBruto;
                }
                else if (SalarioBruto > 2801.56)
                {
                    txtAliquotaINSS.Text = "teto - R$308.17";
                    DescontoINSS = 308.17;
                }
                txtDescontoINSS.Text = DescontoINSS.ToString();
                // ALIQUOTA IRPF
                if(SalarioBruto <= 1257.12)
                {
                    txtAliquotaIRPF.Text = "Isento";
                    DescontoIRPF = 0;
                }
                else if (SalarioBruto >= 1257.13 && SalarioBruto <= 2512.08)
                {
                    txtAliquotaIRPF.Text = "15.00%";
                    DescontoIRPF = SalarioBruto * 0.15;
                }
                else if (SalarioBruto > 2512.08)
                {
                    txtAliquotaIRPF.Text = "27.5%";
                    DescontoIRPF = SalarioBruto * 0.275;
                }
                txtDescontoIRPF.Text = DescontoIRPF.ToString();
                //SALARIO FAMILIA
                if (double.TryParse(txtNumFilhos.Text, out NumFilhos))
                {
                    if (SalarioBruto <= 435.52)
                    {
                        SalarioFamilia = NumFilhos * 22.33;
                    }
                    else if (SalarioBruto >= 435.53 && SalarioBruto <= 654.61)
                    {
                        SalarioFamilia = NumFilhos * 15.74;
                    }
                    else if (SalarioBruto > 654.61)
                    {
                    SalarioFamilia = NumFilhos * 0;
                    }
                    txtSalarioFamilia.Text = SalarioFamilia.ToString();
                }
                //SALARIO LIQUIDO
                SalarioLiquido = SalarioBruto - DescontoINSS - DescontoIRPF + SalarioFamilia;
                txtSalarioLiquido.Text= SalarioLiquido.ToString();
                //MONTAR A MENSAGEM NO LABE
                    LblMensagem.Visible = true;
                    LblMensagem.Text = "Os descontos do salário ";
                    if (rdbtFeminino.Checked)
                    {
                        LblMensagem.Text = LblMensagem.Text + "da Sra " + txtFuncionario.Text;
                    }
                    else
                    {
                        LblMensagem.Text = LblMensagem.Text + "do Sr " + txtFuncionario.Text;
                    }
                    LblMensagem.Text = LblMensagem.Text + " que é ";

                    if (ckbxCasado.Checked)
                    {
                        LblMensagem.Text = LblMensagem.Text + "Casado(a)";
                    }
                    else
                    {
                        LblMensagem.Text = LblMensagem.Text + "Solteiro(a)";
                    }
                    LblMensagem.Text = LblMensagem.Text + " e que tem " + txtNumFilhos.Text + " filhos, são: ";
            }
            else
            {
                MessageBox.Show("Salário Inválido!");
            }
        }
    }
}
