﻿
namespace SalarioPessoal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblFuncionario = new System.Windows.Forms.Label();
            this.txtFuncionario = new System.Windows.Forms.MaskedTextBox();
            this.LblSalarioBruto = new System.Windows.Forms.Label();
            this.LblFilhos = new System.Windows.Forms.Label();
            this.txtSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.GrpBxGenero = new System.Windows.Forms.GroupBox();
            this.btnValidarDesconto = new System.Windows.Forms.Button();
            this.rdbtMasculino = new System.Windows.Forms.RadioButton();
            this.rdbtFeminino = new System.Windows.Forms.RadioButton();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.LblAliquotaINSS = new System.Windows.Forms.Label();
            this.LblAliquotaIRPF = new System.Windows.Forms.Label();
            this.LblSalarioFamilia = new System.Windows.Forms.Label();
            this.LblSalarioLiquido = new System.Windows.Forms.Label();
            this.txtAliquotaINSS = new System.Windows.Forms.MaskedTextBox();
            this.txtAliquotaIRPF = new System.Windows.Forms.MaskedTextBox();
            this.txtSalarioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.txtSalarioLiquido = new System.Windows.Forms.MaskedTextBox();
            this.LblDescontoINSS = new System.Windows.Forms.Label();
            this.LblDescontoIRPF = new System.Windows.Forms.Label();
            this.txtDescontoINSS = new System.Windows.Forms.MaskedTextBox();
            this.txtDescontoIRPF = new System.Windows.Forms.MaskedTextBox();
            this.LblMensagem = new System.Windows.Forms.Label();
            this.txtNumFilhos = new System.Windows.Forms.MaskedTextBox();
            this.GrpBxGenero.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblFuncionario
            // 
            this.LblFuncionario.AutoSize = true;
            this.LblFuncionario.Location = new System.Drawing.Point(24, 31);
            this.LblFuncionario.Name = "LblFuncionario";
            this.LblFuncionario.Size = new System.Drawing.Size(108, 13);
            this.LblFuncionario.TabIndex = 0;
            this.LblFuncionario.Text = "Nome do Funcionário";
            // 
            // txtFuncionario
            // 
            this.txtFuncionario.Location = new System.Drawing.Point(138, 28);
            this.txtFuncionario.Name = "txtFuncionario";
            this.txtFuncionario.Size = new System.Drawing.Size(100, 20);
            this.txtFuncionario.TabIndex = 4;
            // 
            // LblSalarioBruto
            // 
            this.LblSalarioBruto.AutoSize = true;
            this.LblSalarioBruto.Location = new System.Drawing.Point(24, 62);
            this.LblSalarioBruto.Name = "LblSalarioBruto";
            this.LblSalarioBruto.Size = new System.Drawing.Size(67, 13);
            this.LblSalarioBruto.TabIndex = 5;
            this.LblSalarioBruto.Text = "Salário Bruto";
            // 
            // LblFilhos
            // 
            this.LblFilhos.AutoSize = true;
            this.LblFilhos.Location = new System.Drawing.Point(24, 92);
            this.LblFilhos.Name = "LblFilhos";
            this.LblFilhos.Size = new System.Drawing.Size(91, 13);
            this.LblFilhos.TabIndex = 6;
            this.LblFilhos.Text = "Números de filhos";
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(138, 59);
            this.txtSalarioBruto.Mask = "00000.00";
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioBruto.TabIndex = 7;
            // 
            // GrpBxGenero
            // 
            this.GrpBxGenero.Controls.Add(this.rdbtFeminino);
            this.GrpBxGenero.Controls.Add(this.rdbtMasculino);
            this.GrpBxGenero.Location = new System.Drawing.Point(314, 28);
            this.GrpBxGenero.Name = "GrpBxGenero";
            this.GrpBxGenero.Size = new System.Drawing.Size(200, 77);
            this.GrpBxGenero.TabIndex = 9;
            this.GrpBxGenero.TabStop = false;
            this.GrpBxGenero.Text = "Sexo";
            // 
            // btnValidarDesconto
            // 
            this.btnValidarDesconto.Location = new System.Drawing.Point(216, 124);
            this.btnValidarDesconto.Name = "btnValidarDesconto";
            this.btnValidarDesconto.Size = new System.Drawing.Size(110, 23);
            this.btnValidarDesconto.TabIndex = 10;
            this.btnValidarDesconto.Text = "Validar Desconto";
            this.btnValidarDesconto.UseVisualStyleBackColor = true;
            this.btnValidarDesconto.Click += new System.EventHandler(this.btnValidarDesconto_Click);
            // 
            // rdbtMasculino
            // 
            this.rdbtMasculino.AutoSize = true;
            this.rdbtMasculino.Checked = true;
            this.rdbtMasculino.Location = new System.Drawing.Point(6, 19);
            this.rdbtMasculino.Name = "rdbtMasculino";
            this.rdbtMasculino.Size = new System.Drawing.Size(73, 17);
            this.rdbtMasculino.TabIndex = 0;
            this.rdbtMasculino.TabStop = true;
            this.rdbtMasculino.Text = "Masculino";
            this.rdbtMasculino.UseVisualStyleBackColor = true;
            // 
            // rdbtFeminino
            // 
            this.rdbtFeminino.AutoSize = true;
            this.rdbtFeminino.Location = new System.Drawing.Point(6, 42);
            this.rdbtFeminino.Name = "rdbtFeminino";
            this.rdbtFeminino.Size = new System.Drawing.Size(67, 17);
            this.rdbtFeminino.TabIndex = 1;
            this.rdbtFeminino.Text = "Feminino";
            this.rdbtFeminino.UseVisualStyleBackColor = true;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(27, 124);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(62, 17);
            this.ckbxCasado.TabIndex = 11;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // LblAliquotaINSS
            // 
            this.LblAliquotaINSS.AutoSize = true;
            this.LblAliquotaINSS.Location = new System.Drawing.Point(27, 279);
            this.LblAliquotaINSS.Name = "LblAliquotaINSS";
            this.LblAliquotaINSS.Size = new System.Drawing.Size(75, 13);
            this.LblAliquotaINSS.TabIndex = 13;
            this.LblAliquotaINSS.Text = "Alíquota INSS";
            // 
            // LblAliquotaIRPF
            // 
            this.LblAliquotaIRPF.AutoSize = true;
            this.LblAliquotaIRPF.Location = new System.Drawing.Point(27, 304);
            this.LblAliquotaIRPF.Name = "LblAliquotaIRPF";
            this.LblAliquotaIRPF.Size = new System.Drawing.Size(72, 13);
            this.LblAliquotaIRPF.TabIndex = 14;
            this.LblAliquotaIRPF.Text = "Aliquota IRPF";
            // 
            // LblSalarioFamilia
            // 
            this.LblSalarioFamilia.AutoSize = true;
            this.LblSalarioFamilia.Location = new System.Drawing.Point(27, 329);
            this.LblSalarioFamilia.Name = "LblSalarioFamilia";
            this.LblSalarioFamilia.Size = new System.Drawing.Size(76, 13);
            this.LblSalarioFamilia.TabIndex = 15;
            this.LblSalarioFamilia.Text = "Salário Família";
            // 
            // LblSalarioLiquido
            // 
            this.LblSalarioLiquido.AutoSize = true;
            this.LblSalarioLiquido.Location = new System.Drawing.Point(27, 354);
            this.LblSalarioLiquido.Name = "LblSalarioLiquido";
            this.LblSalarioLiquido.Size = new System.Drawing.Size(78, 13);
            this.LblSalarioLiquido.TabIndex = 16;
            this.LblSalarioLiquido.Text = "Salário Líquido";
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Enabled = false;
            this.txtAliquotaINSS.Location = new System.Drawing.Point(138, 272);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaINSS.TabIndex = 17;
            // 
            // txtAliquotaIRPF
            // 
            this.txtAliquotaIRPF.Enabled = false;
            this.txtAliquotaIRPF.Location = new System.Drawing.Point(138, 298);
            this.txtAliquotaIRPF.Name = "txtAliquotaIRPF";
            this.txtAliquotaIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaIRPF.TabIndex = 18;
            // 
            // txtSalarioFamilia
            // 
            this.txtSalarioFamilia.Enabled = false;
            this.txtSalarioFamilia.Location = new System.Drawing.Point(138, 324);
            this.txtSalarioFamilia.Name = "txtSalarioFamilia";
            this.txtSalarioFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioFamilia.TabIndex = 19;
            // 
            // txtSalarioLiquido
            // 
            this.txtSalarioLiquido.Enabled = false;
            this.txtSalarioLiquido.Location = new System.Drawing.Point(138, 350);
            this.txtSalarioLiquido.Name = "txtSalarioLiquido";
            this.txtSalarioLiquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioLiquido.TabIndex = 20;
            // 
            // LblDescontoINSS
            // 
            this.LblDescontoINSS.AutoSize = true;
            this.LblDescontoINSS.Location = new System.Drawing.Point(329, 275);
            this.LblDescontoINSS.Name = "LblDescontoINSS";
            this.LblDescontoINSS.Size = new System.Drawing.Size(81, 13);
            this.LblDescontoINSS.TabIndex = 21;
            this.LblDescontoINSS.Text = "Desconto INSS";
            // 
            // LblDescontoIRPF
            // 
            this.LblDescontoIRPF.AutoSize = true;
            this.LblDescontoIRPF.Location = new System.Drawing.Point(329, 303);
            this.LblDescontoIRPF.Name = "LblDescontoIRPF";
            this.LblDescontoIRPF.Size = new System.Drawing.Size(77, 13);
            this.LblDescontoIRPF.TabIndex = 22;
            this.LblDescontoIRPF.Text = "DescontoIRPF";
            // 
            // txtDescontoINSS
            // 
            this.txtDescontoINSS.Enabled = false;
            this.txtDescontoINSS.Location = new System.Drawing.Point(444, 272);
            this.txtDescontoINSS.Name = "txtDescontoINSS";
            this.txtDescontoINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescontoINSS.TabIndex = 23;
            // 
            // txtDescontoIRPF
            // 
            this.txtDescontoIRPF.Enabled = false;
            this.txtDescontoIRPF.Location = new System.Drawing.Point(444, 300);
            this.txtDescontoIRPF.Name = "txtDescontoIRPF";
            this.txtDescontoIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtDescontoIRPF.TabIndex = 24;
            // 
            // LblMensagem
            // 
            this.LblMensagem.AutoSize = true;
            this.LblMensagem.Location = new System.Drawing.Point(24, 163);
            this.LblMensagem.Name = "LblMensagem";
            this.LblMensagem.Size = new System.Drawing.Size(59, 13);
            this.LblMensagem.TabIndex = 25;
            this.LblMensagem.Text = "Mensagem";
            this.LblMensagem.Visible = false;
            // 
            // txtNumFilhos
            // 
            this.txtNumFilhos.Location = new System.Drawing.Point(138, 85);
            this.txtNumFilhos.Mask = "00";
            this.txtNumFilhos.Name = "txtNumFilhos";
            this.txtNumFilhos.Size = new System.Drawing.Size(100, 20);
            this.txtNumFilhos.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtNumFilhos);
            this.Controls.Add(this.LblMensagem);
            this.Controls.Add(this.txtDescontoIRPF);
            this.Controls.Add(this.txtDescontoINSS);
            this.Controls.Add(this.LblDescontoIRPF);
            this.Controls.Add(this.LblDescontoINSS);
            this.Controls.Add(this.txtSalarioLiquido);
            this.Controls.Add(this.txtSalarioFamilia);
            this.Controls.Add(this.txtAliquotaIRPF);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.LblSalarioLiquido);
            this.Controls.Add(this.LblSalarioFamilia);
            this.Controls.Add(this.LblAliquotaIRPF);
            this.Controls.Add(this.LblAliquotaINSS);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.btnValidarDesconto);
            this.Controls.Add(this.GrpBxGenero);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.LblFilhos);
            this.Controls.Add(this.LblSalarioBruto);
            this.Controls.Add(this.txtFuncionario);
            this.Controls.Add(this.LblFuncionario);
            this.Name = "Form1";
            this.Text = "Form1";
            this.GrpBxGenero.ResumeLayout(false);
            this.GrpBxGenero.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblFuncionario;
        private System.Windows.Forms.MaskedTextBox txtFuncionario;
        private System.Windows.Forms.Label LblSalarioBruto;
        private System.Windows.Forms.Label LblFilhos;
        private System.Windows.Forms.MaskedTextBox txtSalarioBruto;
        private System.Windows.Forms.GroupBox GrpBxGenero;
        private System.Windows.Forms.RadioButton rdbtFeminino;
        private System.Windows.Forms.RadioButton rdbtMasculino;
        private System.Windows.Forms.Button btnValidarDesconto;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.Label LblAliquotaINSS;
        private System.Windows.Forms.Label LblAliquotaIRPF;
        private System.Windows.Forms.Label LblSalarioFamilia;
        private System.Windows.Forms.Label LblSalarioLiquido;
        private System.Windows.Forms.MaskedTextBox txtAliquotaINSS;
        private System.Windows.Forms.MaskedTextBox txtAliquotaIRPF;
        private System.Windows.Forms.MaskedTextBox txtSalarioFamilia;
        private System.Windows.Forms.MaskedTextBox txtSalarioLiquido;
        private System.Windows.Forms.Label LblDescontoINSS;
        private System.Windows.Forms.Label LblDescontoIRPF;
        private System.Windows.Forms.MaskedTextBox txtDescontoINSS;
        private System.Windows.Forms.MaskedTextBox txtDescontoIRPF;
        private System.Windows.Forms.Label LblMensagem;
        private System.Windows.Forms.MaskedTextBox txtNumFilhos;
    }
}

