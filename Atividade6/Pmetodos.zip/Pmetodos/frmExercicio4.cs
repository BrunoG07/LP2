﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCaracterNum_Click(object sender, EventArgs e)
        {
            int caracterTotal = rchtxtTexto.Text.Length;
            int cont, qtdeCaracteres = 0;
            string Texto = rchtxtTexto.Text;


            for (cont = 0; cont < caracterTotal; cont++)
            {
                var c = Texto[cont];
                if(Char.IsNumber(c))
                {
                    qtdeCaracteres++;
                }
                
            }
            MessageBox.Show("A quantidade de caracteres numéricos no texto são: " + qtdeCaracteres);
        }

        private void btnLocalizarCaracterBranco_Click(object sender, EventArgs e)
        {
            int posicaoCaracter = 1, cont = 0;
            string Texto = rchtxtTexto.Text;
            

            while (cont <= rchtxtTexto.Text.Length)
            {
                var x = Texto[cont];
                if (char.IsWhiteSpace(x))
                {
                    break;
                }
                else
                {
                    posicaoCaracter++;
                }
                cont++;
            }
            MessageBox.Show("Posição do 1 caracter em branco é: " + posicaoCaracter);
        }

        private void btnCaractereAlfabético_Click(object sender, EventArgs e)
        {
            int caracterTotal = rchtxtTexto.Text.Length;
            int cont, qtdeCaracteres = 0;
            string Texto = rchtxtTexto.Text;


            foreach (Char c in Texto)
            {
                if (Char.IsLetter(c))
                {
                    qtdeCaracteres++;
                }

            }
            MessageBox.Show("A quantidade de caracteres alfabéticos no texto são: " + qtdeCaracteres);
        }
    
    }
}
