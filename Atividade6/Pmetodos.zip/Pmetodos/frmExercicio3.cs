﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemore1_Click(object sender, EventArgs e)
        {
            //a     tec     s
            //casa  fatec   asessoria
            //cs    fa      aeoria
            //c     fa      a

            int posição = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            while (posição >= 0)
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, posição) + txtPalavra2.Text.Substring(posição + txtPalavra1.Text.Length, txtPalavra2.Text.Length - posição - txtPalavra1.Text.Length);
                posição = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            }


        }

        private void btnRemove2_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void btnRetorne_Click(object sender, EventArgs e)
        {
            char[] texto = txtPalavra1.Text.ToCharArray();
            Array.Reverse(texto);

            txtPalavra2.Text = "";
            foreach (char c in texto)
                txtPalavra2.Text += c;
        }
    }
}
