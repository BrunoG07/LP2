﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            maskedTextBox3.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (double.TryParse(maskedTextBox1.Text, out LadoA) && (double.TryParse(maskedTextBox2.Text, out LadoB)) && (double.TryParse(maskedTextBox3.Text, out LadoC)))
            {
                if (Math.Abs(LadoB - LadoC) < LadoA && LadoA < (LadoB +  LadoC) && Math.Abs(LadoA - LadoC) < LadoB && LadoB < (LadoA + LadoC) && Math.Abs(LadoA - LadoB) < LadoC && LadoC < (LadoA + LadoB))
                {
                    if(LadoA == LadoB && LadoB == LadoC)
                    {
                        MessageBox.Show("Este triângulo é Equilátero");
                    }
                    else if (LadoA == LadoB || LadoB == LadoC || LadoC == LadoA)
                    {
                        MessageBox.Show("Este triângulo é Isósceles");
                    }
                    else
                    {
                        MessageBox.Show("Este triângulo é Escaleno");
                    }
                }
                else
                {
                    MessageBox.Show("Os valores não podem formar um triângulo");
                }
            }
            else
            {
                MessageBox.Show("Dados Incorretos!");
            }
        }
    }
}
