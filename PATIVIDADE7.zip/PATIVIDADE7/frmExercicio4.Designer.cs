﻿
namespace PATIVIDADE7
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNome = new System.Windows.Forms.Label();
            this.LblCargo = new System.Windows.Forms.Label();
            this.LblNumInscrição = new System.Windows.Forms.Label();
            this.LblProdução = new System.Windows.Forms.Label();
            this.LblSalário = new System.Windows.Forms.Label();
            this.LblGratificação = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.masktxtInscricao = new System.Windows.Forms.MaskedTextBox();
            this.masktxtProducao = new System.Windows.Forms.MaskedTextBox();
            this.masktxtSalario = new System.Windows.Forms.MaskedTextBox();
            this.masktxtGratificacao = new System.Windows.Forms.MaskedTextBox();
            this.btnCalculaSalario = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(52, 65);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(41, 13);
            this.LblNome.TabIndex = 0;
            this.LblNome.Text = "Nome: ";
            // 
            // LblCargo
            // 
            this.LblCargo.AutoSize = true;
            this.LblCargo.Location = new System.Drawing.Point(52, 92);
            this.LblCargo.Name = "LblCargo";
            this.LblCargo.Size = new System.Drawing.Size(41, 13);
            this.LblCargo.TabIndex = 1;
            this.LblCargo.Text = "Cargo: ";
            // 
            // LblNumInscrição
            // 
            this.LblNumInscrição.AutoSize = true;
            this.LblNumInscrição.Location = new System.Drawing.Point(52, 126);
            this.LblNumInscrição.Name = "LblNumInscrição";
            this.LblNumInscrição.Size = new System.Drawing.Size(111, 13);
            this.LblNumInscrição.TabIndex = 2;
            this.LblNumInscrição.Text = "Número de Inscrição: ";
            // 
            // LblProdução
            // 
            this.LblProdução.AutoSize = true;
            this.LblProdução.Location = new System.Drawing.Point(52, 161);
            this.LblProdução.Name = "LblProdução";
            this.LblProdução.Size = new System.Drawing.Size(59, 13);
            this.LblProdução.TabIndex = 3;
            this.LblProdução.Text = "Produção: ";
            // 
            // LblSalário
            // 
            this.LblSalário.AutoSize = true;
            this.LblSalário.Location = new System.Drawing.Point(52, 198);
            this.LblSalário.Name = "LblSalário";
            this.LblSalário.Size = new System.Drawing.Size(45, 13);
            this.LblSalário.TabIndex = 4;
            this.LblSalário.Text = "Salário: ";
            // 
            // LblGratificação
            // 
            this.LblGratificação.AutoSize = true;
            this.LblGratificação.Location = new System.Drawing.Point(52, 229);
            this.LblGratificação.Name = "LblGratificação";
            this.LblGratificação.Size = new System.Drawing.Size(72, 13);
            this.LblGratificação.TabIndex = 5;
            this.LblGratificação.Text = "Gratificações:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(169, 62);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 6;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(169, 89);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(100, 20);
            this.txtCargo.TabIndex = 7;
            // 
            // masktxtInscricao
            // 
            this.masktxtInscricao.Location = new System.Drawing.Point(169, 123);
            this.masktxtInscricao.Mask = "00000";
            this.masktxtInscricao.Name = "masktxtInscricao";
            this.masktxtInscricao.Size = new System.Drawing.Size(100, 20);
            this.masktxtInscricao.TabIndex = 8;
            // 
            // masktxtProducao
            // 
            this.masktxtProducao.Location = new System.Drawing.Point(169, 158);
            this.masktxtProducao.Mask = "000";
            this.masktxtProducao.Name = "masktxtProducao";
            this.masktxtProducao.Size = new System.Drawing.Size(100, 20);
            this.masktxtProducao.TabIndex = 9;
            // 
            // masktxtSalario
            // 
            this.masktxtSalario.Location = new System.Drawing.Point(169, 195);
            this.masktxtSalario.Mask = "0000";
            this.masktxtSalario.Name = "masktxtSalario";
            this.masktxtSalario.Size = new System.Drawing.Size(100, 20);
            this.masktxtSalario.TabIndex = 10;
            // 
            // masktxtGratificacao
            // 
            this.masktxtGratificacao.Location = new System.Drawing.Point(169, 226);
            this.masktxtGratificacao.Mask = "000";
            this.masktxtGratificacao.Name = "masktxtGratificacao";
            this.masktxtGratificacao.Size = new System.Drawing.Size(100, 20);
            this.masktxtGratificacao.TabIndex = 11;
            // 
            // btnCalculaSalario
            // 
            this.btnCalculaSalario.Location = new System.Drawing.Point(169, 288);
            this.btnCalculaSalario.Name = "btnCalculaSalario";
            this.btnCalculaSalario.Size = new System.Drawing.Size(119, 50);
            this.btnCalculaSalario.TabIndex = 12;
            this.btnCalculaSalario.Text = "Calcular Salário";
            this.btnCalculaSalario.UseVisualStyleBackColor = true;
            this.btnCalculaSalario.Click += new System.EventHandler(this.btnCalculaSalario_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalculaSalario);
            this.Controls.Add(this.masktxtGratificacao);
            this.Controls.Add(this.masktxtSalario);
            this.Controls.Add(this.masktxtProducao);
            this.Controls.Add(this.masktxtInscricao);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.LblGratificação);
            this.Controls.Add(this.LblSalário);
            this.Controls.Add(this.LblProdução);
            this.Controls.Add(this.LblNumInscrição);
            this.Controls.Add(this.LblCargo);
            this.Controls.Add(this.LblNome);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblCargo;
        private System.Windows.Forms.Label LblNumInscrição;
        private System.Windows.Forms.Label LblProdução;
        private System.Windows.Forms.Label LblSalário;
        private System.Windows.Forms.Label LblGratificação;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.MaskedTextBox masktxtInscricao;
        private System.Windows.Forms.MaskedTextBox masktxtProducao;
        private System.Windows.Forms.MaskedTextBox masktxtSalario;
        private System.Windows.Forms.MaskedTextBox masktxtGratificacao;
        private System.Windows.Forms.Button btnCalculaSalario;
    }
}