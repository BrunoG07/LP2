﻿
namespace PATIVIDADE7
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNumeroN = new System.Windows.Forms.Label();
            this.txtNumeroN = new System.Windows.Forms.TextBox();
            this.btnGerarNum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblNumeroN
            // 
            this.LblNumeroN.AutoSize = true;
            this.LblNumeroN.Location = new System.Drawing.Point(58, 83);
            this.LblNumeroN.Name = "LblNumeroN";
            this.LblNumeroN.Size = new System.Drawing.Size(61, 13);
            this.LblNumeroN.TabIndex = 0;
            this.LblNumeroN.Text = "Número N: ";
            // 
            // txtNumeroN
            // 
            this.txtNumeroN.Location = new System.Drawing.Point(143, 80);
            this.txtNumeroN.Name = "txtNumeroN";
            this.txtNumeroN.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroN.TabIndex = 1;
            // 
            // btnGerarNum
            // 
            this.btnGerarNum.Location = new System.Drawing.Point(143, 144);
            this.btnGerarNum.Name = "btnGerarNum";
            this.btnGerarNum.Size = new System.Drawing.Size(87, 28);
            this.btnGerarNum.TabIndex = 2;
            this.btnGerarNum.Text = "Gerar Número";
            this.btnGerarNum.UseVisualStyleBackColor = true;
            this.btnGerarNum.Click += new System.EventHandler(this.btnGerarNum_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnGerarNum);
            this.Controls.Add(this.txtNumeroN);
            this.Controls.Add(this.LblNumeroN);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNumeroN;
        private System.Windows.Forms.TextBox txtNumeroN;
        private System.Windows.Forms.Button btnGerarNum;
    }
}