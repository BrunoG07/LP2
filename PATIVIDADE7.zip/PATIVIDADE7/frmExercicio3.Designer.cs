﻿
namespace PATIVIDADE7
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestarPalindromo = new System.Windows.Forms.Button();
            this.LblMensagem = new System.Windows.Forms.Label();
            this.txtMensagem = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnTestarPalindromo
            // 
            this.btnTestarPalindromo.Location = new System.Drawing.Point(99, 115);
            this.btnTestarPalindromo.Name = "btnTestarPalindromo";
            this.btnTestarPalindromo.Size = new System.Drawing.Size(100, 47);
            this.btnTestarPalindromo.TabIndex = 0;
            this.btnTestarPalindromo.Text = "Testar se a mensagem é um palindromo";
            this.btnTestarPalindromo.UseVisualStyleBackColor = true;
            this.btnTestarPalindromo.Click += new System.EventHandler(this.btnTestarPalindromo_Click);
            // 
            // LblMensagem
            // 
            this.LblMensagem.AutoSize = true;
            this.LblMensagem.Location = new System.Drawing.Point(28, 58);
            this.LblMensagem.Name = "LblMensagem";
            this.LblMensagem.Size = new System.Drawing.Size(62, 13);
            this.LblMensagem.TabIndex = 1;
            this.LblMensagem.Text = "Mensagem:";
            // 
            // txtMensagem
            // 
            this.txtMensagem.Location = new System.Drawing.Point(99, 55);
            this.txtMensagem.MaxLength = 50;
            this.txtMensagem.Name = "txtMensagem";
            this.txtMensagem.Size = new System.Drawing.Size(100, 20);
            this.txtMensagem.TabIndex = 2;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtMensagem);
            this.Controls.Add(this.LblMensagem);
            this.Controls.Add(this.btnTestarPalindromo);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTestarPalindromo;
        private System.Windows.Forms.Label LblMensagem;
        private System.Windows.Forms.TextBox txtMensagem;
    }
}