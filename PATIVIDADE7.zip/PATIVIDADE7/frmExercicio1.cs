﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PATIVIDADE7
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaçoBranco_Click(object sender, EventArgs e)
        {
            int qtdeCaracterBranco = 0, cont = 0;
            string Texto = richTxtFrase.Text;


            while (cont < richTxtFrase.Text.Length)
            {
                var x = Texto[cont];
                if (char.IsWhiteSpace(x))
                {
                    qtdeCaracterBranco++;
                }
                cont++;
            }
            MessageBox.Show("Quatidade de caracteres em branco é: " + qtdeCaracterBranco);
        }

        private void btnAparecerR_Click(object sender, EventArgs e)
        {
            int qtdeCaracterR = 0;
            int cont;
            string Texto = richTxtFrase.Text;

            for(cont = 0; cont < richTxtFrase.Text.Length; cont++)
            { 
                if(Texto[cont] == 'r' || Texto[cont] == 'R')
                {
                    qtdeCaracterR++;
                }
            }
            MessageBox.Show("Quantidade de letra R é: " + qtdeCaracterR);
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int qtdeCaracterDuplo = 0;
            int cont;
            char letra = ' ';
            string Texto = richTxtFrase.Text;

            for (cont = 0; cont < richTxtFrase.Text.Length; cont++)
            { 
                if(letra == Texto[cont])
                {
                    qtdeCaracterDuplo++;
                }
                letra = Texto[cont];
            }
            MessageBox.Show("Quantidade de Caracter Duplo é: " + qtdeCaracterDuplo);
        }
    }
}
