﻿
namespace PATIVIDADE7
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTxtFrase = new System.Windows.Forms.RichTextBox();
            this.LblFrase = new System.Windows.Forms.Label();
            this.btnEspaçoBranco = new System.Windows.Forms.Button();
            this.btnAparecerR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTxtFrase
            // 
            this.richTxtFrase.Location = new System.Drawing.Point(53, 79);
            this.richTxtFrase.MaxLength = 100;
            this.richTxtFrase.Name = "richTxtFrase";
            this.richTxtFrase.Size = new System.Drawing.Size(100, 96);
            this.richTxtFrase.TabIndex = 0;
            this.richTxtFrase.Text = "";
            // 
            // LblFrase
            // 
            this.LblFrase.AutoSize = true;
            this.LblFrase.Location = new System.Drawing.Point(50, 63);
            this.LblFrase.Name = "LblFrase";
            this.LblFrase.Size = new System.Drawing.Size(33, 13);
            this.LblFrase.TabIndex = 1;
            this.LblFrase.Text = "Frase";
            // 
            // btnEspaçoBranco
            // 
            this.btnEspaçoBranco.Location = new System.Drawing.Point(53, 221);
            this.btnEspaçoBranco.Name = "btnEspaçoBranco";
            this.btnEspaçoBranco.Size = new System.Drawing.Size(108, 63);
            this.btnEspaçoBranco.TabIndex = 2;
            this.btnEspaçoBranco.Text = "Número de Espaços em Branco";
            this.btnEspaçoBranco.UseVisualStyleBackColor = true;
            this.btnEspaçoBranco.Click += new System.EventHandler(this.btnEspaçoBranco_Click);
            // 
            // btnAparecerR
            // 
            this.btnAparecerR.Location = new System.Drawing.Point(167, 221);
            this.btnAparecerR.Name = "btnAparecerR";
            this.btnAparecerR.Size = new System.Drawing.Size(108, 63);
            this.btnAparecerR.TabIndex = 3;
            this.btnAparecerR.Text = "Número de vezes a letra R";
            this.btnAparecerR.UseVisualStyleBackColor = true;
            this.btnAparecerR.Click += new System.EventHandler(this.btnAparecerR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.Location = new System.Drawing.Point(281, 221);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(108, 63);
            this.btnParLetras.TabIndex = 4;
            this.btnParLetras.Text = "Número de Par de Letras";
            this.btnParLetras.UseVisualStyleBackColor = true;
            this.btnParLetras.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnAparecerR);
            this.Controls.Add(this.btnEspaçoBranco);
            this.Controls.Add(this.LblFrase);
            this.Controls.Add(this.richTxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTxtFrase;
        private System.Windows.Forms.Label LblFrase;
        private System.Windows.Forms.Button btnEspaçoBranco;
        private System.Windows.Forms.Button btnAparecerR;
        private System.Windows.Forms.Button btnParLetras;
    }
}